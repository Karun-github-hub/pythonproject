
def fiyathesapla(k)-> float:
    if k == 1:
        if 1<=t<=4:
            return (biletadedi1 * int(dosyaverisi2[1][1]))
        elif int(dosyaverisi2[5][1]) <= t <= int(dosyaverisi2[5][2]):
            return(biletadedi1 * int(dosyaverisi2[1][1])) * (100 - int(dosyaverisi2[5][3])) / 100
        elif int(dosyaverisi2[6][1]) <= t <= int(dosyaverisi2[6][2]):
            return(biletadedi1 * int(dosyaverisi2[1][1]))  * (100 - int(dosyaverisi2[6][3])) / 100
        elif int(dosyaverisi2[7][1]) <= t <= int(dosyaverisi2[7][2]):
            return (biletadedi1 * int(dosyaverisi2[1][1])) * (100 - int(dosyaverisi2[7][3])) / 100
    elif k == 2:
        if 1<=t1<=4:
            return (biletadedi2 * int(dosyaverisi2[2][1]))
        elif int(dosyaverisi2[8][1]) <= t1 <= int(dosyaverisi2[8][2]):
            return (biletadedi2 * int(dosyaverisi2[2][1])) * (100 - int(dosyaverisi2[8][3])) / 100
        elif int(dosyaverisi2[9][1]) <= t1 <= int(dosyaverisi2[9][2]):
            return (biletadedi2 * int(dosyaverisi2[2][1])) * (100 - int(dosyaverisi2[9][3])) / 100
        elif int(dosyaverisi2[10][1]) <= t1 <= int(dosyaverisi2[10][2]):
            return (biletadedi2 * int(dosyaverisi2[2][1]))* (100 - int(dosyaverisi2[10][3])) / 100
    elif k == 3:
        if 1<=t2<=4:
            return (biletadedi3 * int(dosyaverisi2[3][1]))
        elif int(dosyaverisi2[11][1]) <= t2 <= int(dosyaverisi2[11][2]):
            return  (biletadedi3 * int(dosyaverisi2[3][1])) * (100 - int(dosyaverisi2[11][3])) / 100
        elif int(dosyaverisi2[12][1]) <=t2 <= int(dosyaverisi2[12][2]):
            return (biletadedi3 * int(dosyaverisi2[3][1])) * (100 - int(dosyaverisi2[12][3])) / 100
        elif int(dosyaverisi2[13][1]) <= t2 <= int(dosyaverisi2[13][2]):
            return  (biletadedi3 * int(dosyaverisi2[3][1])) * (100 - int(dosyaverisi2[13][3])) / 100
    elif k == 4:
        if 1<=t3<=4:
            return (biletadedi4 * int(dosyaverisi2[4][1]))
        elif int(dosyaverisi2[14][1]) <= t3 <= int(dosyaverisi2[14][2]):
            return (biletadedi4 * int(dosyaverisi2[4][1])) * (100 - int(dosyaverisi2[14][3])) / 100
        elif int(dosyaverisi2[15][1]) <= t3 <= int(dosyaverisi2[15][2]):
            return (biletadedi4 * int(dosyaverisi2[4][1])) * (100 - int(dosyaverisi2[15][3])) / 100
        elif int(dosyaverisi2[16][1]) <= t3 <= int(dosyaverisi2[16][2]):
            return(biletadedi4 * int(dosyaverisi2[4][1])) * (100 - int(dosyaverisi2[16][3])) / 100


koltuk = []
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
koltuk.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

dosyaverisi = []
dosya = open("indirimson.txt", "r")
dosyaverisi = dosya.readlines()
dosya.close()
for h in dosyaverisi:
    h = h.strip()
dosyaverisi2 = []
for say in dosyaverisi:
    dosyaverisi2.append(say.split("-"))
dosyaverisi2[0][0] = "30"
dosyaverisi2 = [list(map(int, i)) for i in dosyaverisi2]

ciro = 0
c1 = 0
c2 = 0
c3 = 0
c4 = 0


musteri=int(input("Müşteri sayısı giriniz"))

for j in range(0,musteri):

    print("Hosgeldiniz")
    alinanbilet = 0

    t = 0
    t1 = 0
    t2 = 0
    t3 = 0
    biletadedi1 = 0
    biletadedi2 = 0
    biletadedi3 = 0
    biletadedi4 = 0
    fiyat=0
    a1=0
    a2=0
    a3=0
    a4=0

    for k in range(0,100):

        BiletAdedi=0
        print("/////////////////ANA MENÜ//////////////////")
        print("Rezervasyon   1\n"
              "Salonu yazdır 2\n"
              "Yeni etkinlik 3\n"
              "Toplam Ciro   4\n"
              "Çıkış         0\n")
        secim = int(input("Lütfen seçiminizi giriniz:"))
        if  alinanbilet != 0:
            print("1.kategorideki alınan biletlerin fiyatı:", a1)
            print("1.kategoriden alınan bilet adedi:", biletadedi1)
            print("2.kategorideki alınan biletlerin fiyatı:", a2)
            print("2.kategoriden alınan bilet adedi:", biletadedi2)
            print("3.kategorideki alınan biletlerin fiyatı:", a3)
            print("3.kategoriden alınan bilet adedi:", biletadedi3)
            print("4.kategorideki aldığınız biletlerin fiyatı:", a4)
            print("4.kategoriden alınan bilet adedi:", biletadedi4)
            fiyat = a1 + a2 + a3 + a4

            print("Toplam fiyat:",fiyat)
            print("Alınan bilet adedi: ", alinanbilet)
            c1 = a1 + c1
            c2 = a2 + c2
            c3 = a3 + c3
            c4 = a4 + c4
        if secim ==0:
            print("çıkış yapılıyor...")

            break

        elif(secim==1):
           kategori=int(input(("(1-4) Kategori seçiniz")))

           BiletAdedi=int(input("Bilet sayısını giriniz"))
           print("Belirli indirimlerimiz bulunmaktadır.Aldığınız bilet adedine göre aldığınız biletlerin fiyatı indirimli şekilde hesaplanacaktır.")
           if(BiletAdedi>10):
              print("1O biletten fazla bilet alamazsınız.")
           elif alinanbilet == int(dosyaverisi2[0][1]):
               print("Daha fazla bilet alınamaz.")

           elif alinanbilet < int(dosyaverisi2[0][1]) < alinanbilet + BiletAdedi:
               print(" Bilet sınırı bulunmaktadır bu sınırı geçemezsiniz\n"
                     "Aldığınız  biletler: ", alinanbilet, "  "
                                                           "Bilet sınırı:", dosyaverisi2[0][1])

           else:
              if(kategori==1):

                 sayac=0
                 t = BiletAdedi + t
                 alinanbilet = alinanbilet + BiletAdedi
                 biletadedi1=biletadedi1+BiletAdedi
                 for i in range(0,BiletAdedi+1):
                     if sayac != BiletAdedi:
                        for satır in range(0, 10):
                            for sutun in range(5, 15):

                                if koltuk[satır][sutun] == 0 and sayac!=BiletAdedi:

                                   print("Rezerve edilen koltuk...")
                                   print("Satır: " + str(satır+1))
                                   print("Sutun: " + str(sutun+1))

                                   koltuk[satır][sutun]=1

                                   sayac=sayac+1

                                elif sayac == BiletAdedi:
                                  break

                                a1 = fiyathesapla(1)

              ele = 1
              kontrol = True


              for satır in range(0,10):
                  for sutun in range(5,15):
                    if ele != koltuk[satır][sutun]:
                      kontrol = False
                      break

              if (kontrol == True):
                  print("Bu kategorideki tüm koltuklar dolu")


              elif(kategori==2):

                     sayac1=0
                     t1 = BiletAdedi + t1
                     alinanbilet = alinanbilet + BiletAdedi
                     biletadedi2=biletadedi2+BiletAdedi
                     for satır in range(0,10) :

                         for sutun in range(4,-1,-1):
                             if koltuk[satır][sutun] == 0 and sayac1 != BiletAdedi:
                                print("Rezerve edilen koltuk...")
                                print("Satır: " + str(satır+1))
                                print("Sutun: " + str(sutun+1))

                                koltuk[satır][sutun] = 1
                                sayac1 = sayac1 + 1

                             elif sayac1 == BiletAdedi:
                              break
                         for sutun in range(15,20):
                             if koltuk[satır][sutun] == 0 and sayac1 != BiletAdedi:
                                print("Rezerve edilen koltuk...")
                                print("Satır: " + str(satır+1))
                                print("Sutun: " + str(sutun+1))

                                koltuk[satır][sutun] = 1
                                sayac1 = sayac1 + 1

                             elif sayac1 == BiletAdedi:
                              break
                             a2 =fiyathesapla(2)

              ele = 1
              kontrol = True

              for satır in range(0,10):
                  for sutun in range(4,-1,-1):
                      if ele != koltuk[satır][sutun]:
                          kontrol = False
                      break

                      for sutun in range(15,20):
                         if ele != koltuk[satır][sutun]:
                            kontrol = False
                         break


              if (kontrol == True):
                  print("Bu kategorideki tüm koltuklar dolu")

              if (kategori == 3):
                  f=0
                  sayac2 =0
                  t2 = BiletAdedi + t2
                  alinanbilet = alinanbilet + BiletAdedi
                  biletadedi3=biletadedi3+BiletAdedi
                  for i in range(0, BiletAdedi + 1):
                      if sayac2 != BiletAdedi:
                          for satır in range(10, 20):
                              for sutun in range(5, 15):
                                  if koltuk[satır][sutun] == 0 and sayac2!= BiletAdedi:
                                      print("Rezerve edilen koltuk...")
                                      print("Satır: " + str(satır+1))
                                      print("Sutun: " + str(sutun+1))

                                      koltuk[satır][sutun] = 1
                                      sayac2 = sayac2 + 1

                                  elif sayac2 == BiletAdedi:
                                      break


                                  a3=fiyathesapla(3)

              ele = 1
              kontrol = True

              for satır in range(10, 20):
                  for sutun in range(5, 15):
                      if ele != koltuk[satır][sutun]:
                          kontrol = False
                          break

              if (kontrol == True):
                  print("Bu kategorideki tüm koltuklar dolu")

              elif (kategori == 4):

                  sayac3 = 0
                  t3 = BiletAdedi + t3
                  alinanbilet = alinanbilet + BiletAdedi
                  biletadedi4=biletadedi4+BiletAdedi
                  for satır in range(10, 20):

                      for sutun in range(4, -1, -1):
                          if koltuk[satır][sutun] == 0 and sayac3 != BiletAdedi:
                              print("Rezerve edilen koltuk...")
                              print("Satır: " + str(satır+1))
                              print("Sutun: " + str(sutun+1))

                              koltuk[satır][sutun] = 1
                              sayac3 = sayac3 + 1
                          elif sayac3 == BiletAdedi:
                              break
                      for sutun in range(15, 20):
                          if koltuk[satır][sutun] == 0 and sayac3 != BiletAdedi:
                              print("Rezerve edilen koltuk...")
                              print("Satır: " + str(satır+1))
                              print("Sutun: " + str(sutun+1))

                              koltuk[satır][sutun] = 1
                              sayac3= sayac3+ 1

                          elif sayac3 == BiletAdedi:
                              break


                          a4 = fiyathesapla(4)
              ele = 1
              kontrol = True

              for satır in range(10, 20):
                  for sutun in range(4, -1, -1):
                      if ele != koltuk[satır][sutun]:
                          kontrol = False
                      break

                      for sutun in range(15, 20):
                          if ele != koltuk[satır][sutun]:
                              kontrol = False
                          break
              if (kontrol == True):
                  print("Bu kategorideki tüm koltuklar dolu")

        elif(secim==2):
             for satır in range(0,20):
                 print("\n")
                 for sutun in range(0,20):
                     if(koltuk[satır][sutun]==1):
                         print("x", end=" ")
                     if(koltuk[satır][sutun]==0):
                        print("-",end=" ")

             print("\n")
        elif (secim==3):

            for satır in range(0,20):
                for sutun in range(0,20):
                    koltuk[satır][sutun]=0

            print("* * * * * * * * SALON * * * * * * * * *")
            for satır in range(0,20):
                for sutun in range(0,20):
                    koltuk[satır][sutun]=0
            for satır in range(0,20):
                print("\n")
                for sutun in range(0,20):
                    print(koltuk[satır][sutun],end=" ")
            print("\n")

            ciro = 0
            c1 = 0
            c2 = 0
            c3 = 0
            c4 = 0
            t = 0
            t1 = 0
            t2 = 0
            t3 = 0
            fiyat = 0
            a1=0
            a2=0
            a3=0
            a4=0
            biletadedi1=0
            biletadedi2=0
            biletadedi3=0
            biletadedi4=0
            alinanbilet = 0

        elif(secim==4):
            ciro = c1 + c2 + c3 + c4
            print("Toplam ciro:", ciro)
            print("1.kategorideki ciro:", c1)
            print("2.kategorideki ciro:", c2)
            print("3.kategorideki ciro:",c3)
            print("4.kategorideki ciro", c4)













